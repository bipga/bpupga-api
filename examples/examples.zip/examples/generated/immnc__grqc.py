import bpupga as bp

# Run from the repository root with the documented import setup.
data = bp.Dataset.load(
    "baseline/data/grqc/bpupga/"
    "rho_s0p6_rho_t0p6/construction_seed_2026")
method = bp.Algorithm(
    "immnc", seed=2026, device="cpu")

# The algorithm receives only graph topology.
result = method.align(data.graph1, data.graph2)
metrics = bp.evaluate(result, data, ks=(1, 5, 10))
print(metrics["pair"])
